import { Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar.jsx';
import Dashboard from './pages/Dashboard.jsx';
import ChartOfAccounts from './pages/ChartOfAccounts.jsx';
import JournalEntries from './pages/JournalEntries.jsx';
import JournalEntryDetail from './pages/JournalEntryDetail.jsx';
import NewJournalEntry from './pages/NewJournalEntry.jsx';
import TrialBalance from './pages/TrialBalance.jsx';
import AccountLedger from './pages/AccountLedger.jsx';
import ProfitLoss from './pages/ProfitLoss.jsx';
import BalanceSheet from './pages/BalanceSheet.jsx';
import CustomerLedger from './pages/CustomerLedger.jsx';
import BranchWise from './pages/BranchWise.jsx';
import SimulateEvents from './pages/SimulateEvents.jsx';
import LoanWorkflow from './pages/LoanWorkflow.jsx';

export default function App() {
  return (
    <div className="shell">
      <Sidebar />
      <main className="main">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/accounts" element={<ChartOfAccounts />} />
          <Route path="/journal-entries" element={<JournalEntries />} />
          <Route path="/journal-entries/new" element={<NewJournalEntry />} />
          <Route path="/journal-entries/:id" element={<JournalEntryDetail />} />
          <Route path="/reports/trial-balance" element={<TrialBalance />} />
          <Route path="/reports/ledger" element={<AccountLedger />} />
          <Route path="/reports/profit-loss" element={<ProfitLoss />} />
          <Route path="/reports/balance-sheet" element={<BalanceSheet />} />
          <Route path="/reports/customer-ledger" element={<CustomerLedger />} />
          <Route path="/reports/branch-wise" element={<BranchWise />} />
          <Route path="/simulate" element={<SimulateEvents />} />
          <Route path="/loan-workflow" element={<LoanWorkflow />} />
        </Routes>
      </main>
    </div>
  );
}
