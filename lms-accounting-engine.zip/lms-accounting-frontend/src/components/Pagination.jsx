export default function Pagination({ page, pageSize, total, onPageChange }) {
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  if (totalPages <= 1) return null;

  return (
    <div className="flex items-center justify-between mt-4 pt-3 border-t border-[var(--rule)]">
      <span className="font-mono text-[0.72rem] text-[var(--ink-soft)] uppercase tracking-wide">
        Page {page} of {totalPages} · {total} total
      </span>
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => onPageChange(page - 1)}
          disabled={page <= 1}
          className="font-mono text-[0.72rem] uppercase border border-[var(--rule-strong)] px-3 py-1.5 rounded-[3px] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[var(--paper)]"
        >
          ← Prev
        </button>
        <button
          type="button"
          onClick={() => onPageChange(page + 1)}
          disabled={page >= totalPages}
          className="font-mono text-[0.72rem] uppercase border border-[var(--rule-strong)] px-3 py-1.5 rounded-[3px] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[var(--paper)]"
        >
          Next →
        </button>
      </div>
    </div>
  );
}
