import { useState } from 'react';

/**
 * Two small buttons that trigger a file download via the given async
 * exporter functions. Built with Tailwind utility classes (per request),
 * layered on top of the existing hand-rolled design system — colors
 * reference the same CSS custom properties as the rest of the app so it
 * doesn't look like a bolted-on component.
 *
 * @param {(format: 'xlsx'|'pdf') => Promise<void>} onExport
 */
export default function ExportButtons({ onExport }) {
  const [busy, setBusy] = useState(null);
  const [error, setError] = useState('');

  async function handle(format) {
    setBusy(format);
    setError('');
    try {
      await onExport(format);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="flex items-center gap-2">
      <button
        type="button"
        onClick={() => handle('xlsx')}
        disabled={busy !== null}
        className="font-mono text-[0.72rem] tracking-wide uppercase border border-[var(--ink)] text-[var(--ink)] px-3 py-1.5 rounded-[3px] hover:bg-[var(--ink)] hover:text-[var(--paper-raised)] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
      >
        {busy === 'xlsx' ? 'Preparing…' : '⇩ XLSX'}
      </button>
      <button
        type="button"
        onClick={() => handle('pdf')}
        disabled={busy !== null}
        className="font-mono text-[0.72rem] tracking-wide uppercase border border-[var(--ink)] text-[var(--ink)] px-3 py-1.5 rounded-[3px] hover:bg-[var(--ink)] hover:text-[var(--paper-raised)] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
      >
        {busy === 'pdf' ? 'Preparing…' : '⇩ PDF'}
      </button>
      {error && <span className="text-[0.78rem] text-[var(--debit)]">{error}</span>}
    </div>
  );
}
