import { NavLink } from 'react-router-dom';

const LINKS = [
  { group: 'Overview', items: [{ to: '/', label: 'Dashboard', idx: '00' }] },
  {
    group: 'Books',
    items: [
      { to: '/accounts', label: 'Chart of Accounts', idx: '01' },
      { to: '/journal-entries', label: 'Journal Entries', idx: '02' },
      { to: '/journal-entries/new', label: 'New Journal Voucher', idx: '03' },
    ],
  },
  {
    group: 'Reports',
    items: [
      { to: '/reports/trial-balance', label: 'Trial Balance', idx: '04' },
      { to: '/reports/ledger', label: 'Account Ledger', idx: '05' },
      { to: '/reports/profit-loss', label: 'Profit & Loss', idx: '06' },
      { to: '/reports/balance-sheet', label: 'Balance Sheet', idx: '07' },
      { to: '/reports/customer-ledger', label: 'Customer Ledger', idx: '08' },
      { to: '/reports/branch-wise', label: 'Branch-wise Summary', idx: '09' },
    ],
  },
  {
    group: 'Loan Lifecycle',
    items: [{ to: '/loan-workflow', label: 'Full Lifecycle Workflow', idx: '10' }],
  },
  {
    group: 'LMS Event Simulator',
    items: [{ to: '/simulate', label: 'Raw Posting Triggers', idx: '11' }],
  },
];

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand">Ledger</div>
      <div className="brand-sub">Accounting Engine · AZZUNIQUE LMS</div>

      {LINKS.map((group) => (
        <div key={group.group}>
          <div className="nav-group-label">{group.group}</div>
          {group.items.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) => 'nav-link' + (isActive ? ' active' : '')}
            >
              <span className="idx">{item.idx}</span>
              <span>{item.label}</span>
            </NavLink>
          ))}
        </div>
      ))}
    </aside>
  );
}
