import { useEffect, useState } from 'react';
import { api } from '../api/client.js';
import PageHeader from '../components/PageHeader.jsx';
import ExportButtons from '../components/ExportButtons.jsx';
import { money } from '../utils/format.js';

export default function ProfitLoss() {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  function load(params = {}) {
    api.getProfitAndLoss(params).then(setData).catch((e) => setError(e.message));
  }

  useEffect(() => load(), []);

  return (
    <>
      <PageHeader
        eyebrow="Reports · 06"
        title="Profit & Loss"
        description="Interest income, processing fee income and penalty income, less expenses, for the selected period."
        action={
          <div style={{ display: 'flex', gap: 10 }}>
            <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} style={{ width: 150 }} />
            <input type="date" value={to} onChange={(e) => setTo(e.target.value)} style={{ width: 150 }} />
            <button className="btn" onClick={() => load({ from: from || undefined, to: to || undefined })}>
              Run
            </button>
          </div>
        }
      />

      {error && <div className="error-banner">{error}</div>}
      {!data && !error && <div className="empty-state">Loading…</div>}

      {data && (
        <>
          <div className="stat-grid">
            <div className="stat-card credit">
              <div className="stat-label">Total income</div>
              <div className="stat-value">{money(data.totalIncome)}</div>
            </div>
            <div className="stat-card debit">
              <div className="stat-label">Total expense</div>
              <div className="stat-value">{money(data.totalExpense)}</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Net {data.netProfit >= 0 ? 'profit' : 'loss'}</div>
              <div className="stat-value">{money(Math.abs(data.netProfit))}</div>
            </div>
          </div>

          <div className="flex justify-end mb-3">
            <ExportButtons onExport={(format) => api.exportProfitAndLoss(format, { from: from || undefined, to: to || undefined })} />
          </div>

          <div className="panel">
            <div className="panel-title">Income</div>
            <table>
              <tbody>
                {data.income.map((r) => (
                  <tr key={r.code}>
                    <td>
                      <span className="account-code">{r.code}</span>
                      {r.name}
                    </td>
                    <td className="num text-credit">{money(r.amount)}</td>
                  </tr>
                ))}
                {data.income.length === 0 && (
                  <tr>
                    <td colSpan={2} className="empty-state">
                      No income posted in this period.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="panel">
            <div className="panel-title">Expense</div>
            <table>
              <tbody>
                {data.expense.map((r) => (
                  <tr key={r.code}>
                    <td>
                      <span className="account-code">{r.code}</span>
                      {r.name}
                    </td>
                    <td className="num text-debit">{money(r.amount)}</td>
                  </tr>
                ))}
                {data.expense.length === 0 && (
                  <tr>
                    <td colSpan={2} className="empty-state">
                      No expense posted in this period.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </>
      )}
    </>
  );
}
