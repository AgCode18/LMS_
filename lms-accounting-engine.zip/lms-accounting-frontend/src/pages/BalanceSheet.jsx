import { useEffect, useState } from 'react';
import { api } from '../api/client.js';
import PageHeader from '../components/PageHeader.jsx';
import ExportButtons from '../components/ExportButtons.jsx';
import { money, shortDate } from '../utils/format.js';

export default function BalanceSheet() {
  const [asOf, setAsOf] = useState('');
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  function load(params = {}) {
    api.getBalanceSheet(params).then(setData).catch((e) => setError(e.message));
  }

  useEffect(() => load(), []);

  function Section({ title, rows, total, accent }) {
    return (
      <div className="panel">
        <div className="panel-title">{title}</div>
        <table>
          <tbody>
            {rows.map((r) => (
              <tr key={r.accountId}>
                <td>
                  <span className="account-code">{r.code}</span>
                  {r.name}
                </td>
                <td className={`num ${accent}`}>{money(r.closingBalance)}</td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={2} className="empty-state">
                  Nothing posted here yet.
                </td>
              </tr>
            )}
          </tbody>
          <tfoot>
            <tr>
              <td style={{ fontFamily: 'var(--font-mono)', textAlign: 'right' }}>Total</td>
              <td className={`num ${accent}`}>{money(total)}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    );
  }

  return (
    <>
      <PageHeader
        eyebrow="Reports · 07"
        title="Balance Sheet"
        description="Assets vs. Liabilities + Equity (including retained earnings from posted P&L) as of a point in time."
        action={
          <div style={{ display: 'flex', gap: 10 }}>
            <input type="date" value={asOf} onChange={(e) => setAsOf(e.target.value)} style={{ width: 160 }} />
            <button className="btn" onClick={() => load({ asOf: asOf || undefined })}>
              Run
            </button>
          </div>
        }
      />

      {error && <div className="error-banner">{error}</div>}
      {!data && !error && <div className="empty-state">Loading…</div>}

      {data && (
        <>
          <div className="stat-grid">
            <div className="stat-card">
              <div className="stat-label">Total assets</div>
              <div className="stat-value">{money(data.totalAssets)}</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Total liabilities + equity</div>
              <div className="stat-value">{money(data.totalLiabilities + data.totalEquity)}</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Balanced?</div>
              <div className="stat-value" style={{ fontSize: '1.1rem' }}>
                {data.balanced ? '✓ Yes' : '✗ No — investigate'}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between mb-1">
            <div className="panel-title !mb-0">As of {shortDate(data.asOf)}</div>
            <ExportButtons onExport={(format) => api.exportBalanceSheet(format, { asOf: asOf || undefined })} />
          </div>
          <Section title="Assets" rows={data.assets} total={data.totalAssets} accent="text-debit" />
          <Section title="Liabilities" rows={data.liabilities} total={data.totalLiabilities} accent="text-credit" />
          <Section
            title={`Equity (incl. retained earnings ${money(data.retainedEarnings)})`}
            rows={data.equity}
            total={data.totalEquity}
            accent="text-credit"
          />
        </>
      )}
    </>
  );
}
