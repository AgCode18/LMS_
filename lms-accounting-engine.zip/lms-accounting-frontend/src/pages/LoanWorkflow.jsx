import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client.js';
import PageHeader from '../components/PageHeader.jsx';
import { money } from '../utils/format.js';

function EligibilityPanel() {
  const [loanApplicationId, setLoanApplicationId] = useState('');
  const [check, setCheck] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function runCheck(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    setCheck(null);
    try {
      setCheck(await api.checkDisbursementEligibility(loanApplicationId));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="panel" onSubmit={runCheck}>
      <div className="panel-title">1 · Check disbursement eligibility</div>
      <div className="helper-text" style={{ marginBottom: 14 }}>
        Verifies KYC = VERIFIED, latest Sanction = APPROVED, latest NACH = ACTIVE, and that this loan
        isn't already disbursed — before any money moves.
      </div>
      <div className="line-row" style={{ gridTemplateColumns: '2fr auto' }}>
        <div className="field">
          <label>Loan application id</label>
          <input value={loanApplicationId} onChange={(e) => setLoanApplicationId(e.target.value)} placeholder="paste from npm run seed" />
        </div>
        <div className="field">
          <button className="btn" disabled={busy || !loanApplicationId}>
            {busy ? 'Checking…' : 'Check'}
          </button>
        </div>
      </div>
      {error && <div className="error-banner">{error}</div>}
      {check && (
        <div className={check.eligible ? 'success-banner' : 'error-banner'}>
          {check.eligible ? '✓ Eligible for disbursement.' : '✗ Not eligible yet:'}
          {!check.eligible && (
            <ul style={{ margin: '8px 0 0 18px' }}>
              {check.reasons.map((r) => (
                <li key={r}>{r}</li>
              ))}
            </ul>
          )}
        </div>
      )}
    </form>
  );
}

function DisburseForm() {
  const [loanApplicationId, setLoanApplicationId] = useState('');
  const [fields, setFields] = useState({
    disbursementMode: 'NEFT',
    bankName: '',
    bankAccountNumber: '',
    ifscCode: '',
    accountHolderName: '',
  });
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    setResult(null);
    try {
      setResult(await api.disburseLoan(loanApplicationId, fields));
    } catch (err) {
      setError(err.message + (err.details ? ': ' + err.details.join('; ') : ''));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="panel" onSubmit={submit}>
      <div className="panel-title">2 · Disburse (creates LoanDisbursement + journal entry, automatically)</div>
      <div className="field">
        <label>Loan application id</label>
        <input required value={loanApplicationId} onChange={(e) => setLoanApplicationId(e.target.value)} />
      </div>
      <div className="line-row">
        <div className="field">
          <label>Mode</label>
          <select value={fields.disbursementMode} onChange={(e) => setFields({ ...fields, disbursementMode: e.target.value })}>
            {['NEFT', 'RTGS', 'IMPS', 'BANK_TRANSFER', 'CHEQUE', 'CASH', 'UPI'].map((m) => (
              <option key={m}>{m}</option>
            ))}
          </select>
        </div>
        <div className="field">
          <label>Bank name</label>
          <input value={fields.bankName} onChange={(e) => setFields({ ...fields, bankName: e.target.value })} />
        </div>
        <div className="field">
          <label>Account no.</label>
          <input value={fields.bankAccountNumber} onChange={(e) => setFields({ ...fields, bankAccountNumber: e.target.value })} />
        </div>
        <div className="field">
          <label>IFSC</label>
          <input value={fields.ifscCode} onChange={(e) => setFields({ ...fields, ifscCode: e.target.value })} />
        </div>
        <div className="field">
          <label>Holder name</label>
          <input value={fields.accountHolderName} onChange={(e) => setFields({ ...fields, accountHolderName: e.target.value })} />
        </div>
      </div>
      <button className="btn" disabled={busy}>
        {busy ? 'Disbursing…' : 'Disburse loan'}
      </button>
      {error && (
        <div className="error-banner" style={{ marginTop: 14 }}>
          {error}
        </div>
      )}
      {result && (
        <div className="success-banner" style={{ marginTop: 14 }}>
          Disbursed {money(result.disbursement.amount)} — journal voucher{' '}
          <span className="mono">{result.journalEntry.voucherNo}</span> was posted automatically.{' '}
          <Link to={`/journal-entries/${result.journalEntry.id}`}>View entry →</Link>
        </div>
      )}
    </form>
  );
}

function EmiCollectForm() {
  const [emiScheduleId, setEmiScheduleId] = useState('');
  const [fields, setFields] = useState({ principalAmount: '', interestAmount: '', paymentMode: 'UPI' });
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    setResult(null);
    try {
      const payload = {
        ...fields,
        principalAmount: Number(fields.principalAmount || 0),
        interestAmount: Number(fields.interestAmount || 0),
      };
      setResult(await api.collectEmiReal(emiScheduleId, payload));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="panel" onSubmit={submit}>
      <div className="panel-title">3 · Collect an EMI (creates EmiPayment + journal entry, automatically)</div>
      <div className="field">
        <label>EMI schedule id</label>
        <input required value={emiScheduleId} onChange={(e) => setEmiScheduleId(e.target.value)} />
      </div>
      <div className="line-row" style={{ gridTemplateColumns: '1fr 1fr 1fr' }}>
        <div className="field">
          <label>Principal</label>
          <input type="number" step="0.01" value={fields.principalAmount} onChange={(e) => setFields({ ...fields, principalAmount: e.target.value })} />
        </div>
        <div className="field">
          <label>Interest</label>
          <input type="number" step="0.01" value={fields.interestAmount} onChange={(e) => setFields({ ...fields, interestAmount: e.target.value })} />
        </div>
        <div className="field">
          <label>Payment mode</label>
          <select value={fields.paymentMode} onChange={(e) => setFields({ ...fields, paymentMode: e.target.value })}>
            {['UPI', 'CASH', 'BANK', 'CHEQUE'].map((m) => (
              <option key={m}>{m}</option>
            ))}
          </select>
        </div>
      </div>
      <button className="btn" disabled={busy}>
        {busy ? 'Collecting…' : 'Collect EMI'}
      </button>
      {error && (
        <div className="error-banner" style={{ marginTop: 14 }}>
          {error}
        </div>
      )}
      {result && (
        <div className="success-banner" style={{ marginTop: 14 }}>
          Collected — journal voucher <span className="mono">{result.journalEntry.voucherNo}</span> was posted automatically.{' '}
          <Link to={`/journal-entries/${result.journalEntry.id}`}>View entry →</Link>
        </div>
      )}
    </form>
  );
}

function ProcessingFeeForm() {
  const [loanApplicationId, setLoanApplicationId] = useState('');
  const [amount, setAmount] = useState('');
  const [collectedImmediately, setCollectedImmediately] = useState(true);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    setResult(null);
    try {
      setResult(await api.chargeProcessingFeeReal(loanApplicationId, { amount: Number(amount), collectedImmediately }));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="bg-[var(--paper-raised)] border border-[var(--rule-strong)] rounded-[4px] p-6 mb-6">
      <div className="panel-title">4 · Charge processing fee (Dr Bank/Customer Receivable · Cr Processing Fee Income)</div>
      <div className="grid grid-cols-[2fr_1fr_1fr_auto] gap-2.5 items-end">
        <div className="field">
          <label>Loan application id</label>
          <input required value={loanApplicationId} onChange={(e) => setLoanApplicationId(e.target.value)} />
        </div>
        <div className="field">
          <label>Amount</label>
          <input required type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} />
        </div>
        <label className="flex items-center gap-2 font-mono text-[0.78rem] text-[var(--ink-soft)] pb-2.5">
          <input
            type="checkbox"
            checked={collectedImmediately}
            onChange={(e) => setCollectedImmediately(e.target.checked)}
            className="w-4 h-4"
          />
          Collected now
        </label>
        <button className="btn" disabled={busy}>
          {busy ? 'Charging…' : 'Charge fee'}
        </button>
      </div>
      <div className="helper-text">
        Uncheck "Collected now" if the fee is only receivable (books it against Customer Receivable instead of Bank).
      </div>
      {error && <div className="error-banner mt-3.5">{error}</div>}
      {result && (
        <div className="success-banner mt-3.5">
          Fee posted — journal voucher <span className="mono">{result.journalEntry.voucherNo}</span>.{' '}
          <Link to={`/journal-entries/${result.journalEntry.id}`}>View entry →</Link>
        </div>
      )}
    </form>
  );
}

function PenaltyForm() {
  const [loanApplicationId, setLoanApplicationId] = useState('');
  const [amount, setAmount] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    setResult(null);
    try {
      setResult(await api.collectPenaltyReal(loanApplicationId, { amount: Number(amount) }));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="bg-[var(--paper-raised)] border border-[var(--rule-strong)] rounded-[4px] p-6 mb-6">
      <div className="panel-title">5 · Collect a standalone penalty (Dr Bank · Cr Penalty Income)</div>
      <div className="grid grid-cols-[2fr_1fr_auto] gap-2.5 items-end">
        <div className="field">
          <label>Loan application id</label>
          <input required value={loanApplicationId} onChange={(e) => setLoanApplicationId(e.target.value)} />
        </div>
        <div className="field">
          <label>Amount</label>
          <input required type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} />
        </div>
        <button className="btn" disabled={busy}>
          {busy ? 'Collecting…' : 'Collect penalty'}
        </button>
      </div>
      {error && <div className="error-banner mt-3.5">{error}</div>}
      {result && (
        <div className="success-banner mt-3.5">
          Penalty posted — journal voucher <span className="mono">{result.journalEntry.voucherNo}</span>.{' '}
          <Link to={`/journal-entries/${result.journalEntry.id}`}>View entry →</Link>
        </div>
      )}
    </form>
  );
}

function WriteOffForm() {
  const [loanApplicationId, setLoanApplicationId] = useState('');
  const [amount, setAmount] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    if (!window.confirm('Write off this loan? This marks it WRITTEN_OFF and cannot be easily undone.')) return;
    setBusy(true);
    setError('');
    setResult(null);
    try {
      setResult(await api.writeOffReal(loanApplicationId, { amount: Number(amount) }));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="bg-[var(--paper-raised)] border border-[var(--rule-strong)] rounded-[4px] p-6 mb-6">
      <div className="panel-title">6 · Write off a loan (Dr Bad Debt Expense · Cr Loan Receivable)</div>
      <div className="grid grid-cols-[2fr_1fr_auto] gap-2.5 items-end">
        <div className="field">
          <label>Loan application id</label>
          <input required value={loanApplicationId} onChange={(e) => setLoanApplicationId(e.target.value)} />
        </div>
        <div className="field">
          <label>Outstanding amount</label>
          <input required type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} />
        </div>
        <button className="btn" style={{ background: 'var(--debit)', borderColor: 'var(--debit)' }} disabled={busy}>
          {busy ? 'Writing off…' : 'Write off loan'}
        </button>
      </div>
      <div className="helper-text">Sets LoanApplication.status to WRITTEN_OFF and posts the bad-debt entry. Confirmed before submitting.</div>
      {error && <div className="error-banner mt-3.5">{error}</div>}
      {result && (
        <div className="success-banner mt-3.5">
          Written off — journal voucher <span className="mono">{result.journalEntry.voucherNo}</span>.{' '}
          <Link to={`/journal-entries/${result.journalEntry.id}`}>View entry →</Link>
        </div>
      )}
    </form>
  );
}

function RecoveryPaymentForm() {
  const [loanRecoveryId, setLoanRecoveryId] = useState('');
  const [amount, setAmount] = useState('');
  const [paymentMode, setPaymentMode] = useState('UPI');
  const [referenceNo, setReferenceNo] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    setResult(null);
    try {
      setResult(await api.recoveryPaymentReal(loanRecoveryId, { amount: Number(amount), paymentMode, referenceNo }));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="bg-[var(--paper-raised)] border border-[var(--rule-strong)] rounded-[4px] p-6 mb-6">
      <div className="panel-title">7 · Record a recovery payment (Dr Bank · Cr Loan Receivable)</div>
      <div className="grid grid-cols-[2fr_1fr_1fr_1fr_auto] gap-2.5 items-end">
        <div className="field">
          <label>Loan recovery id</label>
          <input required value={loanRecoveryId} onChange={(e) => setLoanRecoveryId(e.target.value)} placeholder="from LoanRecovery, not the loan application" />
        </div>
        <div className="field">
          <label>Amount</label>
          <input required type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} />
        </div>
        <div className="field">
          <label>Payment mode</label>
          <select value={paymentMode} onChange={(e) => setPaymentMode(e.target.value)}>
            {['UPI', 'CASH', 'BANK', 'CHEQUE'].map((m) => (
              <option key={m}>{m}</option>
            ))}
          </select>
        </div>
        <div className="field">
          <label>Reference no.</label>
          <input value={referenceNo} onChange={(e) => setReferenceNo(e.target.value)} placeholder="optional" />
        </div>
        <button className="btn" disabled={busy}>
          {busy ? 'Recording…' : 'Record payment'}
        </button>
      </div>
      <div className="helper-text">
        Rejects if the amount exceeds the recovery's outstanding balance. Updates `LoanRecovery.recoveredAmount`/`balanceAmount`.
      </div>
      {error && <div className="error-banner mt-3.5">{error}</div>}
      {result && (
        <div className="success-banner mt-3.5">
          Recovery recorded — journal voucher <span className="mono">{result.journalEntry.voucherNo}</span>.{' '}
          <Link to={`/journal-entries/${result.journalEntry.id}`}>View entry →</Link>
        </div>
      )}
    </form>
  );
}

function RefundForm() {
  const [referenceId, setReferenceId] = useState('');
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    setResult(null);
    try {
      setResult(await api.refundReal({ referenceId, amount: Number(amount), reason }));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="bg-[var(--paper-raised)] border border-[var(--rule-strong)] rounded-[4px] p-6 mb-6">
      <div className="panel-title">8 · Issue a refund (reverses a prior receipt)</div>
      <div className="grid grid-cols-[2fr_1fr_2fr_auto] gap-2.5 items-end">
        <div className="field">
          <label>Reference id</label>
          <input required value={referenceId} onChange={(e) => setReferenceId(e.target.value)} placeholder="loan application id, or any id" />
        </div>
        <div className="field">
          <label>Amount</label>
          <input required type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} />
        </div>
        <div className="field">
          <label>Reason</label>
          <input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. excess EMI payment" />
        </div>
        <button className="btn" disabled={busy}>
          {busy ? 'Issuing…' : 'Issue refund'}
        </button>
      </div>
      {error && <div className="error-banner mt-3.5">{error}</div>}
      {result && (
        <div className="success-banner mt-3.5">
          Refund posted — journal voucher <span className="mono">{result.journalEntry.voucherNo}</span>.{' '}
          <Link to={`/journal-entries/${result.journalEntry.id}`}>View entry →</Link>
        </div>
      )}
    </form>
  );
}

export default function LoanWorkflow() {
  return (
    <>
      <PageHeader
        eyebrow="Loan lifecycle · real controllers"
        title="Loan Lifecycle Workflow"
        description="The actual gated workflow, not raw accounting triggers: disbursement checks KYC/Sanction/NACH before it will move money, and every step here creates its own LMS record before handing off to the accounting engine automatically."
      />
      <EligibilityPanel />
      <DisburseForm />
      <EmiCollectForm />
      <ProcessingFeeForm />
      <PenaltyForm />
      <WriteOffForm />
      <RecoveryPaymentForm />
      <RefundForm />
    </>
  );
}
