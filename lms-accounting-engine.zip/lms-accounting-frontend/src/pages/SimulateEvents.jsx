import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client.js';
import PageHeader from '../components/PageHeader.jsx';

const EVENTS = {
  loanDisbursement: {
    label: 'Loan Disbursement',
    hint: 'Dr Loan Receivable · Cr Bank Account',
    fields: [
      { key: 'loanApplicationId', label: 'Loan application id', placeholder: 'e.g. from prisma studio' },
      { key: 'amount', label: 'Amount', type: 'number' },
    ],
    call: api.postLoanDisbursement,
  },
  emiCollection: {
    label: 'EMI Collection',
    hint: 'Dr Bank · Cr Loan Receivable, Interest Income, Penalty Income, Bounce Income',
    fields: [
      { key: 'emiScheduleId', label: 'EMI schedule id' },
      { key: 'loanApplicationId', label: 'Loan application id (for narration)' },
      { key: 'principalAmount', label: 'Principal amount', type: 'number' },
      { key: 'interestAmount', label: 'Interest amount', type: 'number' },
      { key: 'penaltyAmount', label: 'Penalty amount (optional)', type: 'number' },
      { key: 'bounceAmount', label: 'Bounce charges (optional)', type: 'number' },
    ],
    call: api.postEmiCollection,
  },
  processingFee: {
    label: 'Processing Fee',
    hint: 'Dr Customer/Bank · Cr Processing Fee Income',
    fields: [
      { key: 'loanApplicationId', label: 'Loan application id' },
      { key: 'amount', label: 'Amount', type: 'number' },
    ],
    call: api.postProcessingFee,
  },
  penaltyCollection: {
    label: 'Penalty Collection',
    hint: 'Dr Bank · Cr Penalty Income',
    fields: [
      { key: 'referenceId', label: 'Reference id (loan/customer)' },
      { key: 'amount', label: 'Amount', type: 'number' },
    ],
    call: api.postPenaltyCollection,
  },
  writeOff: {
    label: 'Loan Write-Off',
    hint: 'Dr Bad Debt Expense · Cr Loan Receivable',
    fields: [
      { key: 'loanApplicationId', label: 'Loan application id' },
      { key: 'amount', label: 'Outstanding amount', type: 'number' },
    ],
    call: api.postWriteOff,
  },
  recoveryPayment: {
    label: 'Recovery Payment',
    hint: 'Dr Bank · Cr Loan Receivable',
    fields: [
      { key: 'loanApplicationId', label: 'Loan application id' },
      { key: 'customerId', label: 'Customer id' },
      { key: 'amount', label: 'Amount recovered', type: 'number' },
    ],
    call: api.postRecoveryPayment,
  },
  refund: {
    label: 'Refund',
    hint: 'Reverses a prior receipt',
    fields: [
      { key: 'referenceId', label: 'Reference id' },
      { key: 'amount', label: 'Amount', type: 'number' },
      { key: 'reason', label: 'Reason' },
    ],
    call: api.postRefund,
  },
};

function EventCard({ eventKey, def }) {
  const [values, setValues] = useState({});
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    setResult(null);
    try {
      const payload = {};
      for (const f of def.fields) {
        if (values[f.key] === undefined || values[f.key] === '') continue;
        payload[f.key] = f.type === 'number' ? Number(values[f.key]) : values[f.key];
      }
      const entry = await def.call(payload);
      setResult(entry);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="panel" onSubmit={submit}>
      <div className="panel-title">{def.label}</div>
      <div className="helper-text" style={{ marginBottom: 14 }}>
        {def.hint}
      </div>
      {def.fields.map((f) => (
        <div className="field" key={f.key}>
          <label>{f.label}</label>
          <input
            type={f.type || 'text'}
            step={f.type === 'number' ? '0.01' : undefined}
            placeholder={f.placeholder}
            value={values[f.key] || ''}
            onChange={(e) => setValues({ ...values, [f.key]: e.target.value })}
          />
        </div>
      ))}
      <button className="btn" disabled={busy}>
        {busy ? 'Posting…' : `Fire ${def.label}`}
      </button>

      {error && <div className="error-banner" style={{ marginTop: 14 }}>{error}</div>}
      {result && (
        <div className="success-banner" style={{ marginTop: 14 }}>
          Posted <span className="mono">{result.voucherNo}</span> — total {result.totalDebit}.{' '}
          <Link to={`/journal-entries/${result.id}`}>View entry →</Link>
        </div>
      )}
    </form>
  );
}

export default function SimulateEvents() {
  return (
    <>
      <PageHeader
        eyebrow="LMS Event Simulator · 08"
        title="Simulate postings"
        description="Fire each accounting event by hand — this is exactly what your real loan-application, EMI, and recovery controllers should call once they're wired to this engine (see README → 'Wiring into your real LMS'). Run npm run seed in the backend first; it prints a demo loanApplicationId/customerId/emiScheduleId you can paste below."
      />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        {Object.entries(EVENTS).map(([key, def]) => (
          <EventCard key={key} eventKey={key} def={def} />
        ))}
      </div>
    </>
  );
}
