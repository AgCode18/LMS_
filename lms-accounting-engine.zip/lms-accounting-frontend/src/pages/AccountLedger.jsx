import { useEffect, useState } from 'react';
import { api } from '../api/client.js';
import PageHeader from '../components/PageHeader.jsx';
import ExportButtons from '../components/ExportButtons.jsx';
import { money, shortDate } from '../utils/format.js';

// The PDF names these three ledgers explicitly ("Bank Ledger", "Loan
// Ledger", "Interest Income Ledger") — rather than separate pages, they're
// just this same Account Ledger pointed at a specific account, offered
// here as one-click shortcuts.
const QUICK_LEDGERS = [
  { systemKey: 'BANK_ACCOUNT', label: 'Bank Ledger' },
  { systemKey: 'LOAN_RECEIVABLE', label: 'Loan Ledger' },
  { systemKey: 'INTEREST_INCOME', label: 'Interest Income Ledger' },
];

export default function AccountLedger() {
  const [accounts, setAccounts] = useState([]);
  const [accountId, setAccountId] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [ledger, setLedger] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.getAccounts().then(setAccounts).catch((e) => setError(e.message));
  }, []);

  function load(id, params = {}) {
    if (!id) return;
    api.getAccountLedger(id, params).then(setLedger).catch((e) => setError(e.message));
  }

  function handleAccountChange(id) {
    setAccountId(id);
    setLedger(null);
    load(id, { from: from || undefined, to: to || undefined });
  }

  return (
    <>
      <PageHeader
        eyebrow="Reports · 05"
        title="Account Ledger"
        description="Every posted line for a single account with a running balance — the classic T-account view, laid out as a register."
      />

      {error && <div className="error-banner">{error}</div>}

      <div className="flex items-center gap-2 mb-4">
        <span className="font-mono text-[0.68rem] uppercase tracking-wide text-[var(--ink-soft)]">Quick access:</span>
        {QUICK_LEDGERS.map((q) => {
          const acc = accounts.find((a) => a.systemKey === q.systemKey);
          return (
            <button
              key={q.systemKey}
              type="button"
              disabled={!acc}
              onClick={() => handleAccountChange(acc.id)}
              className="font-mono text-[0.72rem] uppercase border border-[var(--brass)] text-[var(--brass)] px-3 py-1 rounded-full hover:bg-[var(--brass)] hover:text-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              {q.label}
            </button>
          );
        })}
      </div>

      <div className="panel">
        <div className="line-row" style={{ gridTemplateColumns: '2fr 1fr 1fr auto' }}>
          <div className="field">
            <label>Account</label>
            <select value={accountId} onChange={(e) => handleAccountChange(e.target.value)}>
              <option value="">Select account…</option>
              {accounts.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.code} — {a.name}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>From</label>
            <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </div>
          <div className="field">
            <label>To</label>
            <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          </div>
          <button className="btn" onClick={() => load(accountId, { from: from || undefined, to: to || undefined })} disabled={!accountId}>
            Run
          </button>
        </div>
      </div>

      {!accountId && <div className="empty-state">Choose an account to see its ledger.</div>}

      {ledger && (
        <>
          <div className="stat-grid">
            <div className="stat-card">
              <div className="stat-label">{ledger.account.code} — {ledger.account.name}</div>
              <div className="stat-value" style={{ fontSize: '1.1rem' }}>
                {ledger.account.type}
              </div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Opening balance</div>
              <div className="stat-value">{money(ledger.openingBalance)}</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Closing balance</div>
              <div className="stat-value">{money(ledger.closingBalance)}</div>
            </div>
          </div>

          <div className="panel">
            <div className="flex items-center justify-between mb-3.5">
              <div className="panel-title !mb-0">Transactions</div>
              <ExportButtons
                onExport={(format) => api.exportAccountLedger(accountId, format, { from: from || undefined, to: to || undefined })}
              />
            </div>
            {ledger.rows.length === 0 && <div className="empty-state">No posted movements in this range yet.</div>}
            {ledger.rows.length > 0 && (
              <table>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Voucher</th>
                    <th>Narration</th>
                    <th className="num">Debit</th>
                    <th className="num">Credit</th>
                    <th className="num">Balance</th>
                  </tr>
                </thead>
                <tbody>
                  {ledger.rows.map((r, i) => (
                    <tr key={i}>
                      <td>{shortDate(r.date)}</td>
                      <td className="mono">{r.voucherNo}</td>
                      <td>{r.narration}</td>
                      <td className="num text-debit">{r.debit ? money(r.debit) : ''}</td>
                      <td className="num text-credit">{r.credit ? money(r.credit) : ''}</td>
                      <td className="num">{money(r.runningBalance)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </>
      )}
    </>
  );
}
