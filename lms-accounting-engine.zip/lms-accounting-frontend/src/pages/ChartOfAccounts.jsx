import { useEffect, useState } from 'react';
import { api } from '../api/client.js';
import PageHeader from '../components/PageHeader.jsx';
import Pagination from '../components/Pagination.jsx';
import { money } from '../utils/format.js';

const TYPES = ['ASSET', 'LIABILITY', 'INCOME', 'EXPENSE', 'EQUITY'];
const PAGE_SIZE = 10;

function flatten(nodes, depth = 0, out = []) {
  for (const n of nodes) {
    out.push({ ...n, depth });
    if (n.children?.length) flatten(n.children, depth + 1, out);
  }
  return out;
}

export default function ChartOfAccounts() {
  const [tree, setTree] = useState(null);
  const [error, setError] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ code: '', name: '', type: 'ASSET', description: '' });
  const [codeAuto, setCodeAuto] = useState(true); // true = let the backend keep auto-generating as type changes
  const [saving, setSaving] = useState(false);

  // Search + pagination (flat, server-side) — shown instead of the tree
  // once the user starts typing a search term.
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [searchResult, setSearchResult] = useState(null);

  function loadTree() {
    api.getAccountTree().then(setTree).catch((e) => setError(e.message));
  }

  useEffect(loadTree, []);

  useEffect(() => {
    if (!search.trim()) {
      setSearchResult(null);
      return;
    }
    const handle = setTimeout(() => {
      api
        .getAccounts({ search: search.trim(), page, pageSize: PAGE_SIZE })
        .then(setSearchResult)
        .catch((e) => setError(e.message));
    }, 250); // debounce so we're not firing a request on every keystroke
    return () => clearTimeout(handle);
  }, [search, page]);

  useEffect(() => {
    if (!showForm || !codeAuto) return;
    api
      .getNextAccountCode(form.type)
      .then((res) => setForm((f) => ({ ...f, code: res.code })))
      .catch(() => {});
  }, [showForm, codeAuto, form.type]);

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await api.createAccount(form);
      setForm({ code: '', name: '', type: 'ASSET', description: '' });
      setCodeAuto(true);
      setShowForm(false);
      loadTree();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  const treeRows = tree ? flatten(tree) : [];
  const isSearching = search.trim().length > 0;

  return (
    <>
      <PageHeader
        eyebrow="Books · 01"
        title="Chart of Accounts"
        description="Every ledger account the engine can post to. Assets and Expenses carry a natural debit balance; Liabilities, Income and Equity carry a natural credit balance."
        action={
          <button className="btn" onClick={() => setShowForm((s) => !s)}>
            {showForm ? 'Cancel' : '+ New account'}
          </button>
        }
      />

      {error && <div className="error-banner">{error}</div>}

      {showForm && (
        <form className="panel" onSubmit={handleSubmit}>
          <div className="panel-title">New ledger account</div>
          <div className="line-row" style={{ gridTemplateColumns: '1fr 2fr 1fr 2fr auto' }}>
            <div className="field">
              <label>Code</label>
              <input
                required
                value={form.code}
                onChange={(e) => {
                  setCodeAuto(false);
                  setForm({ ...form, code: e.target.value });
                }}
                placeholder="auto"
              />
              {codeAuto && (
                <div className="helper-text">Auto-generated for {form.type} — edit to override</div>
              )}
            </div>
            <div className="field">
              <label>Name</label>
              <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Petty Cash" />
            </div>
            <div className="field">
              <label>Type</label>
              <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                {TYPES.map((t) => (
                  <option key={t}>{t}</option>
                ))}
              </select>
            </div>
            <div className="field">
              <label>Description</label>
              <input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="optional" />
            </div>
            <div className="field">
              <button className="btn" disabled={saving}>
                {saving ? 'Saving…' : 'Create'}
              </button>
            </div>
          </div>
        </form>
      )}

      <div className="panel">
        <div className="flex items-center justify-between gap-4 mb-4">
          <div className="panel-title !mb-0">{isSearching ? 'Search results' : 'Ledger tree'}</div>
          <input
            type="text"
            placeholder="Search by account name or code…"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            className="max-w-xs"
          />
        </div>

        {!isSearching && !tree && <div className="empty-state">Loading…</div>}
        {!isSearching && tree && treeRows.length === 0 && (
          <div className="empty-state">
            No accounts yet — run <code>npm run seed</code> in the backend to load the sample Chart of Accounts.
          </div>
        )}

        {!isSearching && treeRows.length > 0 && (
          <table>
            <thead>
              <tr>
                <th>Account</th>
                <th>Type</th>
                <th>Status</th>
                <th className="num">Opening</th>
                <th className="num">Current balance</th>
              </tr>
            </thead>
            <tbody>
              {treeRows.map((r) => (
                <tr key={r.id}>
                  <td style={{ paddingLeft: 10 + r.depth * 22 }}>
                    <span className="account-code">{r.code}</span>
                    {r.name}
                  </td>
                  <td className="mono">{r.type}</td>
                  <td className="mono">{r.status}</td>
                  <td className="num">{money(r.openingBalance)}</td>
                  <td className="num">{money(r.currentBalance)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {isSearching && !searchResult && <div className="empty-state">Searching…</div>}
        {isSearching && searchResult && searchResult.data.length === 0 && (
          <div className="empty-state">No accounts match "{search}".</div>
        )}
        {isSearching && searchResult && searchResult.data.length > 0 && (
          <>
            <table>
              <thead>
                <tr>
                  <th>Account</th>
                  <th>Type</th>
                  <th>Status</th>
                  <th className="num">Opening</th>
                  <th className="num">Current balance</th>
                </tr>
              </thead>
              <tbody>
                {searchResult.data.map((r) => (
                  <tr key={r.id}>
                    <td>
                      <span className="account-code">{r.code}</span>
                      {r.name}
                    </td>
                    <td className="mono">{r.type}</td>
                    <td className="mono">{r.status}</td>
                    <td className="num">{money(r.openingBalance)}</td>
                    <td className="num">{money(r.currentBalance)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <Pagination page={page} pageSize={PAGE_SIZE} total={searchResult.total} onPageChange={setPage} />
          </>
        )}
      </div>
    </>
  );
}
