import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api/client.js';
import PageHeader from '../components/PageHeader.jsx';
import { money } from '../utils/format.js';

const emptyLine = () => ({ accountId: '', debit: '', credit: '', description: '' });

export default function NewJournalEntry() {
  const navigate = useNavigate();
  const [accounts, setAccounts] = useState([]);
  const [narration, setNarration] = useState('');
  const [transactionDate, setTransactionDate] = useState(new Date().toISOString().slice(0, 10));
  const [lines, setLines] = useState([emptyLine(), emptyLine()]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.getAccounts().then(setAccounts).catch((e) => setError(e.message));
  }, []);

  const totalDebit = lines.reduce((s, l) => s + Number(l.debit || 0), 0);
  const totalCredit = lines.reduce((s, l) => s + Number(l.credit || 0), 0);
  const balanced = Math.abs(totalDebit - totalCredit) < 0.005 && totalDebit > 0;

  function updateLine(idx, patch) {
    setLines((prev) => prev.map((l, i) => (i === idx ? { ...l, ...patch } : l)));
  }

  function addLine() {
    setLines((prev) => [...prev, emptyLine()]);
  }

  function removeLine(idx) {
    setLines((prev) => prev.filter((_, i) => i !== idx));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    if (!balanced) {
      setError('Debits must equal credits before this voucher can be posted.');
      return;
    }
    setSaving(true);
    try {
      const entry = await api.createJournalEntry({
        narration,
        transactionDate,
        referenceType: 'MANUAL',
        status: 'POSTED',
        lines: lines
          .filter((l) => l.accountId && (l.debit || l.credit))
          .map((l) => ({
            accountId: l.accountId,
            debit: Number(l.debit || 0),
            credit: Number(l.credit || 0),
            description: l.description,
          })),
      });
      navigate(`/journal-entries/${entry.id}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <PageHeader
        eyebrow="Books · 03"
        title="New journal voucher"
        description="For manual adjustments the auto-posting rules don't cover — e.g. salary expense, a capital infusion, or a correction."
      />

      {error && <div className="error-banner">{error}</div>}

      <form className="panel" onSubmit={handleSubmit}>
        <div className="line-row" style={{ gridTemplateColumns: '2fr 1fr' }}>
          <div className="field">
            <label>Narration</label>
            <input required value={narration} onChange={(e) => setNarration(e.target.value)} placeholder="e.g. Office rent for July" />
          </div>
          <div className="field">
            <label>Transaction date</label>
            <input type="date" required value={transactionDate} onChange={(e) => setTransactionDate(e.target.value)} />
          </div>
        </div>

        <div className="panel-title" style={{ marginTop: 20 }}>
          Lines
        </div>
        {lines.map((line, idx) => (
          <div className="line-row" key={idx}>
            <div className="field">
              <label>Account</label>
              <select required value={line.accountId} onChange={(e) => updateLine(idx, { accountId: e.target.value })}>
                <option value="">Select account…</option>
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.code} — {a.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label>Debit</label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={line.debit}
                onChange={(e) => updateLine(idx, { debit: e.target.value, credit: e.target.value ? '' : line.credit })}
              />
            </div>
            <div className="field">
              <label>Credit</label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={line.credit}
                onChange={(e) => updateLine(idx, { credit: e.target.value, debit: e.target.value ? '' : line.debit })}
              />
            </div>
            <div className="field">
              <label>Description</label>
              <input value={line.description} onChange={(e) => updateLine(idx, { description: e.target.value })} placeholder="optional" />
            </div>
            <button type="button" className="btn secondary" onClick={() => removeLine(idx)} disabled={lines.length <= 2}>
              Remove
            </button>
          </div>
        ))}

        <button type="button" className="btn secondary" onClick={addLine} style={{ marginBottom: 20 }}>
          + Add line
        </button>

        <div className="stat-grid" style={{ marginBottom: 20 }}>
          <div className="stat-card debit">
            <div className="stat-label">Total debit</div>
            <div className="stat-value">{money(totalDebit)}</div>
          </div>
          <div className="stat-card credit">
            <div className="stat-label">Total credit</div>
            <div className="stat-value">{money(totalCredit)}</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Balanced?</div>
            <div className="stat-value" style={{ fontSize: '1.1rem' }}>
              {balanced ? '✓ Yes' : '✗ Not yet'}
            </div>
          </div>
        </div>

        <button className="btn" disabled={!balanced || saving}>
          {saving ? 'Posting…' : 'Post voucher'}
        </button>
      </form>
    </>
  );
}
