import { useEffect, useState } from 'react';
import { api } from '../api/client.js';
import PageHeader from '../components/PageHeader.jsx';
import ExportButtons from '../components/ExportButtons.jsx';
import { money, shortDate } from '../utils/format.js';

export default function TrialBalance() {
  const [asOf, setAsOf] = useState('');
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  function load(params = {}) {
    api.getTrialBalance(params).then(setData).catch((e) => setError(e.message));
  }

  useEffect(() => load(), []);

  return (
    <>
      <PageHeader
        eyebrow="Reports · 04"
        title="Trial Balance"
        description="Every account's total debits and credits posted so far. Total Debit = Total Credit is the check that the books balance."
        action={
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <input type="date" value={asOf} onChange={(e) => setAsOf(e.target.value)} style={{ width: 160 }} />
            <button className="btn" onClick={() => load({ asOf: asOf || undefined })}>
              Run
            </button>
          </div>
        }
      />

      {error && <div className="error-banner">{error}</div>}
      {!data && !error && <div className="empty-state">Loading…</div>}

      {data && (
        <>
          <div className="stat-grid">
            <div className="stat-card debit">
              <div className="stat-label">Total debit</div>
              <div className="stat-value">{money(data.totalDebit)}</div>
            </div>
            <div className="stat-card credit">
              <div className="stat-label">Total credit</div>
              <div className="stat-value">{money(data.totalCredit)}</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Books balanced?</div>
              <div className="stat-value" style={{ fontSize: '1.1rem' }}>
                {data.balanced ? '✓ Yes' : '✗ No — investigate'}
              </div>
            </div>
          </div>

          <div className="panel">
            <div className="flex items-center justify-between mb-3.5">
              <div className="panel-title !mb-0">As of {shortDate(data.asOf)}</div>
              <ExportButtons onExport={(format) => api.exportTrialBalance(format, { asOf: asOf || undefined })} />
            </div>
            <table>
              <thead>
                <tr>
                  <th>Account</th>
                  <th>Type</th>
                  <th className="num">Total debit</th>
                  <th className="num">Total credit</th>
                  <th className="num">Closing balance</th>
                </tr>
              </thead>
              <tbody>
                {data.rows.map((r) => (
                  <tr key={r.accountId}>
                    <td>
                      <span className="account-code">{r.code}</span>
                      {r.name}
                    </td>
                    <td className="mono">{r.type}</td>
                    <td className="num text-debit">{r.totalDebit ? money(r.totalDebit) : ''}</td>
                    <td className="num text-credit">{r.totalCredit ? money(r.totalCredit) : ''}</td>
                    <td className="num">{money(r.closingBalance)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </>
  );
}
