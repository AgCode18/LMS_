import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../api/client.js';
import PageHeader from '../components/PageHeader.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import { money, dateTime } from '../utils/format.js';

export default function JournalEntryDetail() {
  const { id } = useParams();
  const [entry, setEntry] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  function load() {
    api.getJournalEntry(id).then(setEntry).catch((e) => setError(e.message));
  }

  useEffect(load, [id]); // eslint-disable-line react-hooks/exhaustive-deps

  async function handlePost() {
    setBusy(true);
    try {
      await api.postJournalEntry(id);
      load();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleCancel() {
    if (!window.confirm('Cancel this voucher? This reverses its effect on account balances.')) return;
    setBusy(true);
    try {
      await api.cancelJournalEntry(id);
      load();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  if (error) return <div className="error-banner">{error}</div>;
  if (!entry) return <div className="empty-state">Loading…</div>;

  return (
    <>
      <PageHeader
        eyebrow="Books · 02"
        title={entry.voucherNo}
        description={entry.narration}
        action={
          <div style={{ display: 'flex', gap: 10 }}>
            {entry.status === 'DRAFT' && (
              <button className="btn" onClick={handlePost} disabled={busy}>
                Post entry
              </button>
            )}
            {entry.status !== 'CANCELLED' && (
              <button className="btn secondary" onClick={handleCancel} disabled={busy}>
                Cancel entry
              </button>
            )}
          </div>
        }
      />

      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-label">Status</div>
          <div className="stat-value">
            <StatusBadge status={entry.status} />
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Transaction date</div>
          <div className="stat-value" style={{ fontSize: '1.1rem' }}>
            {dateTime(entry.transactionDate)}
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Reference</div>
          <div className="stat-value" style={{ fontSize: '1.1rem' }}>
            {entry.referenceType || '—'}
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Total</div>
          <div className="stat-value">{money(entry.totalDebit)}</div>
        </div>
      </div>

      <div className="panel">
        <div className="panel-title">Ledger lines</div>
        <table>
          <thead>
            <tr>
              <th>Account</th>
              <th>Description</th>
              <th className="num">Debit</th>
              <th className="num">Credit</th>
            </tr>
          </thead>
          <tbody>
            {entry.lines.map((l) => (
              <tr key={l.id}>
                <td>
                  <span className="account-code">{l.account.code}</span>
                  {l.account.name}
                </td>
                <td>{l.description || '—'}</td>
                <td className="num text-debit">{l.debit ? money(l.debit) : ''}</td>
                <td className="num text-credit">{l.credit ? money(l.credit) : ''}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <td colSpan={2} style={{ textAlign: 'right', fontFamily: 'var(--font-mono)' }}>
                Total
              </td>
              <td className="num text-debit">{money(entry.totalDebit)}</td>
              <td className="num text-credit">{money(entry.totalCredit)}</td>
            </tr>
          </tfoot>
        </table>
      </div>

      <Link to="/journal-entries" className="helper-text">
        ← Back to all journal entries
      </Link>
    </>
  );
}
