import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client.js';
import PageHeader from '../components/PageHeader.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import { money, dateTime } from '../utils/format.js';

export default function Dashboard() {
  const [tb, setTb] = useState(null);
  const [pnl, setPnl] = useState(null);
  const [recent, setRecent] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([api.getTrialBalance(), api.getProfitAndLoss(), api.getJournalEntries({ pageSize: 8 })])
      .then(([tbRes, pnlRes, recentRes]) => {
        setTb(tbRes);
        setPnl(pnlRes);
        setRecent(recentRes);
      })
      .catch((e) => setError(e.message));
  }, []);

  const assetTotal = tb?.rows.filter((r) => r.type === 'ASSET').reduce((s, r) => s + r.closingBalance, 0) ?? 0;
  const liabilityTotal = tb?.rows.filter((r) => r.type === 'LIABILITY').reduce((s, r) => s + r.closingBalance, 0) ?? 0;

  return (
    <>
      <PageHeader
        eyebrow="Ledger overview"
        title="Accounting Engine"
        description="Live position of the books, derived entirely from posted journal entries — nothing here is hand-entered."
        action={
          <Link to="/journal-entries/new" className="btn">
            + New voucher
          </Link>
        }
      />

      {error && <div className="error-banner">{error}
        <div className="helper-text">Is the API running? Check VITE_API_URL / that the backend is started (see README).</div>
      </div>}

      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-label">Total Assets</div>
          <div className="stat-value">{money(assetTotal)}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Total Liabilities</div>
          <div className="stat-value">{money(liabilityTotal)}</div>
        </div>
        <div className="stat-card credit">
          <div className="stat-label">Income (all-time)</div>
          <div className="stat-value">{money(pnl?.totalIncome)}</div>
        </div>
        <div className="stat-card debit">
          <div className="stat-label">Expense (all-time)</div>
          <div className="stat-value">{money(pnl?.totalExpense)}</div>
        </div>
      </div>

      <div className="panel">
        <div className="panel-title">Recent journal vouchers</div>
        {!recent && !error && <div className="empty-state">Loading…</div>}
        {recent && recent.data.length === 0 && (
          <div className="empty-state">
            No journal entries yet. Post one from the Simulate Postings page, or run <code>npm run seed</code> in the
            backend first to load the Chart of Accounts.
          </div>
        )}
        {recent && recent.data.length > 0 && (
          <table>
            <thead>
              <tr>
                <th>Voucher</th>
                <th>Date</th>
                <th>Narration</th>
                <th>Reference</th>
                <th className="num">Amount</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {recent.data.map((e) => (
                <tr key={e.id}>
                  <td>
                    <Link to={`/journal-entries/${e.id}`} className="mono">
                      {e.voucherNo}
                    </Link>
                  </td>
                  <td>{dateTime(e.transactionDate)}</td>
                  <td>{e.narration}</td>
                  <td className="mono">{e.referenceType || '—'}</td>
                  <td className="num">{money(e.totalDebit)}</td>
                  <td>
                    <StatusBadge status={e.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
