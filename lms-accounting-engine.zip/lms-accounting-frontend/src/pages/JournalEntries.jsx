import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client.js';
import PageHeader from '../components/PageHeader.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import Pagination from '../components/Pagination.jsx';
import ExportButtons from '../components/ExportButtons.jsx';
import { money, dateTime } from '../utils/format.js';

const REFERENCE_TYPES = [
  '',
  'LOAN_DISBURSEMENT',
  'EMI_PAYMENT',
  'RECOVERY',
  'FORECLOSURE',
  'PROCESSING_FEE',
  'PARTNER_COMMISSION',
  'PENALTY',
  'WRITE_OFF',
  'REFUND',
  'MANUAL',
];

const PAGE_SIZE = 15;

export default function JournalEntries() {
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [filters, setFilters] = useState({ referenceType: '', status: '', accountSearch: '' });
  const [page, setPage] = useState(1);

  function load(f, p) {
    api
      .getJournalEntries({ ...f, page: p, pageSize: PAGE_SIZE })
      .then(setResult)
      .catch((e) => setError(e.message));
  }

  // Debounce the free-text account search; other filters/page changes
  // fire immediately. This single effect also covers the initial load.
  useEffect(() => {
    const handle = setTimeout(() => load(filters, page), filters.accountSearch ? 300 : 0);
    return () => clearTimeout(handle);
  }, [filters, page]); // eslint-disable-line react-hooks/exhaustive-deps

  function updateFilter(key, value) {
    setFilters((f) => ({ ...f, [key]: value }));
    setPage(1);
  }

  return (
    <>
      <PageHeader
        eyebrow="Books · 02"
        title="Journal Entries"
        description="Every voucher posted by the accounting engine, whether triggered automatically by an LMS event or entered manually."
        action={
          <Link to="/journal-entries/new" className="btn">
            + New voucher
          </Link>
        }
      />

      {error && <div className="error-banner">{error}</div>}

      <div className="panel">
        <div className="line-row" style={{ gridTemplateColumns: '1fr 1fr 1.4fr', marginBottom: 0 }}>
          <div className="field">
            <label>Reference type</label>
            <select value={filters.referenceType} onChange={(e) => updateFilter('referenceType', e.target.value)}>
              {REFERENCE_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t || 'All'}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>Status</label>
            <select value={filters.status} onChange={(e) => updateFilter('status', e.target.value)}>
              <option value="">All</option>
              <option value="DRAFT">Draft</option>
              <option value="POSTED">Posted</option>
              <option value="CANCELLED">Cancelled</option>
            </select>
          </div>
          <div className="field">
            <label>Search by account name</label>
            <input
              type="text"
              placeholder="e.g. Bank Account, Loan Receivable…"
              value={filters.accountSearch}
              onChange={(e) => updateFilter('accountSearch', e.target.value)}
            />
          </div>
        </div>
      </div>

      <div className="panel">
        <div className="flex items-center justify-between mb-3.5">
          <div className="panel-title !mb-0">
            {result ? `${result.total} voucher${result.total === 1 ? '' : 's'}` : 'Vouchers'}
          </div>
          <ExportButtons
            onExport={(format) =>
              api.exportJournalEntries(format, {
                referenceType: filters.referenceType || undefined,
                status: filters.status || undefined,
                accountSearch: filters.accountSearch || undefined,
              })
            }
          />
        </div>
        {!result && <div className="empty-state">Loading…</div>}
        {result && result.data.length === 0 && <div className="empty-state">No journal entries match these filters.</div>}
        {result && result.data.length > 0 && (
          <>
            <table>
              <thead>
                <tr>
                  <th>Voucher</th>
                  <th>Date</th>
                  <th>Narration</th>
                  <th>Reference</th>
                  <th className="num">Debit</th>
                  <th className="num">Credit</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {result.data.map((e) => (
                  <tr key={e.id}>
                    <td>
                      <Link to={`/journal-entries/${e.id}`} className="mono">
                        {e.voucherNo}
                      </Link>
                    </td>
                    <td>{dateTime(e.transactionDate)}</td>
                    <td>{e.narration}</td>
                    <td className="mono">{e.referenceType || '—'}</td>
                    <td className="num text-debit">{money(e.totalDebit)}</td>
                    <td className="num text-credit">{money(e.totalCredit)}</td>
                    <td>
                      <StatusBadge status={e.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <Pagination page={result.page} pageSize={result.pageSize} total={result.total} onPageChange={setPage} />
          </>
        )}
      </div>
    </>
  );
}
