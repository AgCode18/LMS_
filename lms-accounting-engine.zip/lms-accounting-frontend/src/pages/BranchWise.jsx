import { useEffect, useState } from 'react';
import { api } from '../api/client.js';
import PageHeader from '../components/PageHeader.jsx';
import { money } from '../utils/format.js';

export default function BranchWise() {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  function load() {
    api
      .getBranchWise({ from: from || undefined, to: to || undefined })
      .then(setData)
      .catch((e) => setError(e.message));
  }

  useEffect(load, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <>
      <PageHeader
        eyebrow="Reports · Branch"
        title="Branch-wise Summary"
        description="Posted disbursement totals and loan application counts, grouped by branch."
      />

      <form
        className="panel"
        onSubmit={(e) => {
          e.preventDefault();
          load();
        }}
      >
        <div className="line-row" style={{ gridTemplateColumns: '1fr 1fr auto' }}>
          <div className="field">
            <label>From</label>
            <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </div>
          <div className="field">
            <label>To</label>
            <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          </div>
          <div className="field">
            <button className="btn">Apply</button>
          </div>
        </div>
      </form>

      {error && <div className="error-banner">{error}</div>}

      <div className="panel">
        <div className="panel-title">Disbursements by branch (posted only)</div>
        {!data && <div className="empty-state">Loading…</div>}
        {data && data.disbursementsByBranch.length === 0 && <div className="empty-state">No posted disbursements yet.</div>}
        {data && data.disbursementsByBranch.length > 0 && (
          <table>
            <thead>
              <tr>
                <th>Branch id</th>
                <th className="num">Disbursement count</th>
                <th className="num">Total disbursed</th>
              </tr>
            </thead>
            <tbody>
              {data.disbursementsByBranch.map((row) => (
                <tr key={row.branchId}>
                  <td className="mono">{row.branchId}</td>
                  <td className="num">{row._count._all}</td>
                  <td className="num">{money(row._sum.amount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="panel">
        <div className="panel-title">Loan applications by branch</div>
        {data && data.applicationsByBranch.length === 0 && <div className="empty-state">No loan applications yet.</div>}
        {data && data.applicationsByBranch.length > 0 && (
          <table>
            <thead>
              <tr>
                <th>Branch id</th>
                <th className="num">Applications</th>
              </tr>
            </thead>
            <tbody>
              {data.applicationsByBranch.map((row) => (
                <tr key={row.branchId}>
                  <td className="mono">{row.branchId}</td>
                  <td className="num">{row._count._all}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
