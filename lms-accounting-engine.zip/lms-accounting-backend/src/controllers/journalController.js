const asyncHandler = require('../middleware/asyncHandler');
const journalService = require('../services/journalService');
const { toXlsxBuffer, toPdfBuffer } = require('../services/exportService');

exports.list = asyncHandler(async (req, res) => {
  const { referenceType, status, from, to, accountSearch, page, pageSize } = req.query;
  res.json(
    await journalService.listJournalEntries({
      referenceType,
      status,
      from,
      to,
      accountSearch,
      page: page ? Number(page) : undefined,
      pageSize: pageSize ? Number(pageSize) : undefined,
    })
  );
});

exports.exportList = asyncHandler(async (req, res) => {
  const { referenceType, status, from, to, accountSearch, format } = req.query;
  // No pagination on export — pull everything matching the filters (capped
  // generously so an accidental unfiltered export can't hang the server).
  const result = await journalService.listJournalEntries({
    referenceType,
    status,
    from,
    to,
    accountSearch,
    page: 1,
    pageSize: 5000,
  });

  const columns = [
    { key: 'voucherNo', header: 'Voucher' },
    { key: 'date', header: 'Date' },
    { key: 'narration', header: 'Narration' },
    { key: 'referenceType', header: 'Reference' },
    { key: 'totalDebit', header: 'Debit', numeric: true },
    { key: 'totalCredit', header: 'Credit', numeric: true },
    { key: 'status', header: 'Status' },
  ];
  const rows = result.data.map((e) => ({
    voucherNo: e.voucherNo,
    date: new Date(e.transactionDate).toLocaleDateString('en-IN'),
    narration: e.narration || '',
    referenceType: e.referenceType || '',
    totalDebit: e.totalDebit,
    totalCredit: e.totalCredit,
    status: e.status,
  }));

  if (format === 'pdf') {
    const buffer = await toPdfBuffer('Journal Entries', columns, rows, { subtitle: `${result.total} voucher(s)` });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="journal-entries.pdf"');
    return res.send(buffer);
  }
  const buffer = await toXlsxBuffer('Journal Entries', columns, rows);
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename="journal-entries.xlsx"');
  return res.send(buffer);
});

exports.get = asyncHandler(async (req, res) => {
  res.json(await journalService.getJournalEntry(req.params.id));
});

// Manual journal entry — for adjustments the auto-posting rules don't cover
// (e.g. salary expense, capital infusion). Mirrors createJournal() directly.
exports.create = asyncHandler(async (req, res) => {
  const { narration, referenceType, referenceId, lines, transactionDate, status, createdById } = req.body;
  const entry = await journalService.createJournal({
    narration,
    referenceType,
    referenceId,
    lines,
    transactionDate: transactionDate ? new Date(transactionDate) : undefined,
    status: status || 'POSTED',
    createdById,
  });
  res.status(201).json(entry);
});

exports.post = asyncHandler(async (req, res) => {
  res.json(await journalService.postDraft(req.params.id));
});

exports.cancel = asyncHandler(async (req, res) => {
  res.json(await journalService.cancelJournal(req.params.id));
});
