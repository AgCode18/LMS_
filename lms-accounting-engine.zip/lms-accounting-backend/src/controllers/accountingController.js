const asyncHandler = require('../middleware/asyncHandler');
const autoPosting = require('../services/autoPostingService');

// These endpoints exist so your existing loan-application / EMI /
// recovery controllers can call the accounting engine over HTTP without
// importing its internals directly. If your real backend is a single
// Node project, prefer calling the autoPostingService functions in
// process (see README) — it's the same logic, just skips the HTTP hop.

exports.loanDisbursement = asyncHandler(async (req, res) => {
  res.status(201).json(await autoPosting.postLoanDisbursement(req.body));
});

exports.emiCollection = asyncHandler(async (req, res) => {
  res.status(201).json(await autoPosting.postEmiCollection(req.body));
});

exports.penaltyCollection = asyncHandler(async (req, res) => {
  res.status(201).json(await autoPosting.postPenaltyCollection(req.body));
});

exports.processingFee = asyncHandler(async (req, res) => {
  res.status(201).json(await autoPosting.postProcessingFee(req.body));
});

exports.refund = asyncHandler(async (req, res) => {
  res.status(201).json(await autoPosting.postRefund(req.body));
});

exports.writeOff = asyncHandler(async (req, res) => {
  res.status(201).json(await autoPosting.postWriteOff(req.body));
});

exports.recoveryPayment = asyncHandler(async (req, res) => {
  res.status(201).json(await autoPosting.postRecoveryPayment(req.body));
});
