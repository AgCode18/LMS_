const asyncHandler = require('../middleware/asyncHandler');
const lifecycle = require('../services/loanLifecycleService');

exports.checkEligibility = asyncHandler(async (req, res) => {
  const result = await lifecycle.checkDisbursementEligibility(req.params.id);
  res.json({ eligible: result.eligible, reasons: result.reasons });
});

exports.disburse = asyncHandler(async (req, res) => {
  const result = await lifecycle.disburseLoan({ loanApplicationId: req.params.id, ...req.body });
  res.status(201).json(result);
});

exports.collectEmi = asyncHandler(async (req, res) => {
  const result = await lifecycle.collectEmi({ emiScheduleId: req.params.emiScheduleId, ...req.body });
  res.status(201).json(result);
});

exports.collectPenalty = asyncHandler(async (req, res) => {
  const result = await lifecycle.collectPenalty({ loanApplicationId: req.params.id, ...req.body });
  res.status(201).json(result);
});

exports.chargeProcessingFee = asyncHandler(async (req, res) => {
  const result = await lifecycle.chargeProcessingFee({ loanApplicationId: req.params.id, ...req.body });
  res.status(201).json(result);
});

exports.refund = asyncHandler(async (req, res) => {
  const result = await lifecycle.issueRefund(req.body);
  res.status(201).json(result);
});

exports.writeOff = asyncHandler(async (req, res) => {
  const result = await lifecycle.writeOffLoan({ loanApplicationId: req.params.id, ...req.body });
  res.status(201).json(result);
});

exports.recoveryPayment = asyncHandler(async (req, res) => {
  const result = await lifecycle.recordRecoveryPayment({ loanRecoveryId: req.params.loanRecoveryId, ...req.body });
  res.status(201).json(result);
});
