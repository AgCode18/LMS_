const asyncHandler = require('../middleware/asyncHandler');
const reportService = require('../services/reportService');
const { toXlsxBuffer, toPdfBuffer } = require('../services/exportService');

async function sendExport(res, format, filenameBase, title, columns, rows, subtitle) {
  if (format === 'pdf') {
    const buffer = await toPdfBuffer(title, columns, rows, { subtitle });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filenameBase}.pdf"`);
    return res.send(buffer);
  }
  const buffer = await toXlsxBuffer(title, columns, rows);
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${filenameBase}.xlsx"`);
  return res.send(buffer);
}

exports.trialBalance = asyncHandler(async (req, res) => {
  res.json(await reportService.trialBalance({ asOf: req.query.asOf }));
});

exports.trialBalanceExport = asyncHandler(async (req, res) => {
  const tb = await reportService.trialBalance({ asOf: req.query.asOf });
  const columns = [
    { key: 'code', header: 'Code' },
    { key: 'name', header: 'Account' },
    { key: 'type', header: 'Type' },
    { key: 'totalDebit', header: 'Total Debit', numeric: true },
    { key: 'totalCredit', header: 'Total Credit', numeric: true },
    { key: 'closingBalance', header: 'Closing Balance', numeric: true },
  ];
  await sendExport(res, req.query.format, 'trial-balance', 'Trial Balance', columns, tb.rows, `As of ${tb.asOf}`);
});

exports.accountLedger = asyncHandler(async (req, res) => {
  res.json(await reportService.accountLedger(req.params.accountId, { from: req.query.from, to: req.query.to }));
});

exports.accountLedgerExport = asyncHandler(async (req, res) => {
  const ledger = await reportService.accountLedger(req.params.accountId, { from: req.query.from, to: req.query.to });
  const columns = [
    { key: 'date', header: 'Date' },
    { key: 'voucherNo', header: 'Voucher' },
    { key: 'narration', header: 'Narration' },
    { key: 'debit', header: 'Debit', numeric: true },
    { key: 'credit', header: 'Credit', numeric: true },
    { key: 'runningBalance', header: 'Running Balance', numeric: true },
  ];
  const rows = ledger.rows.map((r) => ({ ...r, date: new Date(r.date).toLocaleDateString('en-IN') }));
  await sendExport(
    res,
    req.query.format,
    'account-ledger',
    `Ledger — ${ledger.account.code} ${ledger.account.name}`,
    columns,
    rows
  );
});

exports.profitAndLoss = asyncHandler(async (req, res) => {
  res.json(await reportService.profitAndLoss({ from: req.query.from, to: req.query.to }));
});

exports.profitAndLossExport = asyncHandler(async (req, res) => {
  const pnl = await reportService.profitAndLoss({ from: req.query.from, to: req.query.to });
  const columns = [
    { key: 'code', header: 'Code' },
    { key: 'name', header: 'Account' },
    { key: 'section', header: 'Section' },
    { key: 'amount', header: 'Amount', numeric: true },
  ];
  const rows = [
    ...pnl.income.map((r) => ({ ...r, section: 'Income' })),
    ...pnl.expense.map((r) => ({ ...r, section: 'Expense' })),
    { code: '', name: 'Net Profit', section: '', amount: pnl.netProfit },
  ];
  await sendExport(
    res,
    req.query.format,
    'profit-and-loss',
    'Profit & Loss Statement',
    columns,
    rows,
    `${pnl.from || 'inception'} to ${pnl.to || 'date'}`
  );
});

exports.balanceSheet = asyncHandler(async (req, res) => {
  res.json(await reportService.balanceSheet({ asOf: req.query.asOf }));
});

exports.balanceSheetExport = asyncHandler(async (req, res) => {
  const bs = await reportService.balanceSheet({ asOf: req.query.asOf });
  const columns = [
    { key: 'code', header: 'Code' },
    { key: 'name', header: 'Account' },
    { key: 'section', header: 'Section' },
    { key: 'closingBalance', header: 'Balance', numeric: true },
  ];
  const rows = [
    ...bs.assets.map((r) => ({ ...r, section: 'Asset' })),
    ...bs.liabilities.map((r) => ({ ...r, section: 'Liability' })),
    ...bs.equity.map((r) => ({ ...r, section: 'Equity' })),
    { code: '', name: 'Retained Earnings (P&L)', section: 'Equity', closingBalance: bs.retainedEarnings },
  ];
  await sendExport(res, req.query.format, 'balance-sheet', 'Balance Sheet', columns, rows, `As of ${bs.asOf}`);
});

exports.customerLedger = asyncHandler(async (req, res) => {
  res.json(await reportService.customerLedger(req.params.customerId));
});

exports.branchWise = asyncHandler(async (req, res) => {
  res.json(await reportService.branchWiseSummary({ from: req.query.from, to: req.query.to }));
});
