const express = require('express');
const ctrl = require('../controllers/loanLifecycleController');

const router = express.Router();

router.get('/:id/disbursement-eligibility', ctrl.checkEligibility);
router.post('/:id/disburse', ctrl.disburse);
router.post('/emi/:emiScheduleId/collect', ctrl.collectEmi);
router.post('/:id/penalty', ctrl.collectPenalty);
router.post('/:id/processing-fee', ctrl.chargeProcessingFee);
router.post('/refund', ctrl.refund);
router.post('/:id/write-off', ctrl.writeOff);
router.post('/recovery/:loanRecoveryId/payment', ctrl.recoveryPayment);

module.exports = router;
