const express = require('express');
const ctrl = require('../controllers/reportController');

const router = express.Router();

router.get('/trial-balance', ctrl.trialBalance);
router.get('/trial-balance/export', ctrl.trialBalanceExport);
router.get('/profit-loss', ctrl.profitAndLoss);
router.get('/profit-loss/export', ctrl.profitAndLossExport);
router.get('/balance-sheet', ctrl.balanceSheet);
router.get('/balance-sheet/export', ctrl.balanceSheetExport);
router.get('/ledger/:accountId', ctrl.accountLedger);
router.get('/ledger/:accountId/export', ctrl.accountLedgerExport);
router.get('/customer-ledger/:customerId', ctrl.customerLedger);
router.get('/branch-wise', ctrl.branchWise);

module.exports = router;
