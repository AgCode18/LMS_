const express = require('express');
const ctrl = require('../controllers/accountController');

const router = express.Router();

router.get('/tree', ctrl.tree);
router.get('/next-code', ctrl.nextCode);
router.get('/', ctrl.list);
router.get('/:id', ctrl.get);
router.post('/', ctrl.create);
router.patch('/:id', ctrl.update);

module.exports = router;
