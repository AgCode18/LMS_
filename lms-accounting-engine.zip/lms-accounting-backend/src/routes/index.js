const express = require('express');

const router = express.Router();

router.use('/accounts', require('./accounts.routes'));
router.use('/journal-entries', require('./journal.routes'));
router.use('/accounting', require('./accounting.routes'));
router.use('/reports', require('./reports.routes'));
router.use('/loans', require('./loans.routes'));

router.get('/health', (req, res) => res.json({ status: 'ok' }));

module.exports = router;
