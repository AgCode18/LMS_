const express = require('express');
const ctrl = require('../controllers/journalController');

const router = express.Router();

router.get('/', ctrl.list);
router.get('/export', ctrl.exportList);
router.get('/:id', ctrl.get);
router.post('/', ctrl.create);
router.post('/:id/post', ctrl.post);
router.post('/:id/cancel', ctrl.cancel);

module.exports = router;
